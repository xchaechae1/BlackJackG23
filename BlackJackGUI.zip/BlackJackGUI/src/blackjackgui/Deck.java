package LRJ23;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class Deck {
    private List<Card> cards; // List to hold all cards in the deck

    // initialise deck with all card values
    public Deck() {
        cards = new ArrayList<>();
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};

        // Map ranks to corresponding Blackjack card values
        Map<String, Integer> rankValues = new HashMap<>();
        rankValues.put("2", 2);
        rankValues.put("3", 3);
        rankValues.put("4", 4);
        rankValues.put("5", 5);
        rankValues.put("6", 6);
        rankValues.put("7", 7);
        rankValues.put("8", 8);
        rankValues.put("9", 9);
        rankValues.put("10", 10);
        rankValues.put("Jack", 10);
        rankValues.put("Queen", 10);
        rankValues.put("King", 10);
        rankValues.put("Ace", 11); // Ace initially counts as 11 can also be worth 1 if over 21 with ace being 11

        // Create a card for each rank and suit
        for (String suit : suits) {
            for (String rank : rankValues.keySet()) {
                int value = rankValues.get(rank);
                cards.add(new Card(suit, rank, value));
            }
        }
    }

    // Shuffle the deck
    public void shuffle() {
        Collections.shuffle(cards);
    }

    // Draw a card from top 
    public Card drawCard() {
        return cards.remove(0); // Remove and return the first card that is drawn 
    }

    // Gets the value of the card 
    public int getCardValue(Card card) {
        return card.getValue();
    }

    // Get number of cards left in deck
    public int size() {
        return cards.size();
    }
}
