/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjackgui;

import java.sql.*;


public final class DBManager {

    // Derby network (client) connection
    private static final String URL = "jdbc:derby://localhost:1527/BlackJackGame";
    private static final String USER_NAME = "pdc";
    private static final String PASSWORD = "pdc";

    private Connection conn;

    // Constructor automatically connects and ensures table exists
    public DBManager() {
        establishConnection();
        ensureUsersTableExists();
    }

    // Get current connection
    public Connection getConnection() {
        return this.conn;
    }

    // Establish Derby connection
    public void establishConnection() {
        if (this.conn == null) {
            try {
                // Load Derby network driver
                Class.forName("org.apache.derby.jdbc.ClientDriver");

                conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
                System.out.println("Connected successfully to " + URL);
            } catch (ClassNotFoundException e) {
                System.out.println("Derby client driver not found. Add derbyclient.jar to your dependencies.");
            } catch (SQLException ex) {
                System.out.println("Connection failed: " + ex.getMessage());
            }
        }
    }

    // Close connection safely
    public void closeConnections() {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Connection closed.");
            } catch (SQLException ex) {
                System.out.println("Failed to close connection: " + ex.getMessage());
            }
        }
    }

    // Execute SELECT queries
    public ResultSet queryDB(String sql) {
        try {
            Statement statement = conn.createStatement();
            return statement.executeQuery(sql);
        } catch (SQLException ex) {
            System.out.println("Query failed: " + ex.getMessage());
            return null;
        }
    }

    // Execute INSERT/UPDATE/DELETE
    public void updateDB(String sql) {
        try {
            Statement statement = conn.createStatement();
            statement.executeUpdate(sql);
            System.out.println("Update executed successfully.");
        } catch (SQLException ex) {
            System.out.println("Update failed: " + ex.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // ✅ USER LOGIN & REGISTRATION SUPPORT
    // -------------------------------------------------------------------------

    /**
     * Ensures the USERS table exists.
     * Only runs on startup — safe to call multiple times.
     */
    public void ensureUsersTableExists() {
        try (Statement st = conn.createStatement()) {
            st.executeUpdate("CREATE TABLE USERS (USERNAME VARCHAR(50) PRIMARY KEY, PASSWORD VARCHAR(50))");
            System.out.println("✅ USERS table created successfully.");
        } catch (SQLException e) {
            // SQLState X0Y32 = Table already exists in Derby
            if (!"X0Y32".equals(e.getSQLState())) {
                System.out.println("USERS table check error: " + e.getMessage());
            }
        }
    }

    /**
     * Registers a new user in the USERS table.
     * @return true if registration successful, false if username already exists.
     */
    public boolean registerUser(String username, String password) {
        String sql = "INSERT INTO USERS (USERNAME, PASSWORD) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            System.out.println("User registered successfully: " + username);
            return true;
        } catch (SQLException e) {
            System.out.println("Registration failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Validates username and password against the USERS table.
     * @return true if credentials match, false otherwise.
     */
    public boolean validateUser(String username, String password) {
        String sql = "SELECT * FROM USERS WHERE USERNAME = ? AND PASSWORD = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            boolean valid = rs.next();
            if (valid) {
                System.out.println("Login success for user: " + username);
            } else {
                System.out.println("Invalid login attempt for user: " + username);
            }
            return valid;
        } catch (SQLException e) {
            System.out.println("Login validation failed: " + e.getMessage());
            return false;
        }
    }


    public static void main(String[] args) {
        DBManager db = new DBManager();

        if (db.getConnection() != null) {
            System.out.println("🎉 Connection established!");

            // Optional: test registration + login
            db.registerUser("testUser", "12345");
            boolean ok = db.validateUser("testUser", "12345");
            System.out.println("Login test: " + ok);

            db.closeConnections();
        } else {
            System.out.println("⚠️ Connection failed!");
        }
    }
}
