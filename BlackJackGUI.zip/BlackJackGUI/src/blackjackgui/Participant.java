package LRJ23;


public abstract class Participant {
    protected Hand hand; // The player's hand of cards

    // new empty hand
    public Participant() {
        hand = new Hand();
    }

    // Adds a card to hand
    public void addCard(Card card) {
        hand.addCard(card);
    }

    // total value of hand
    public int getHandValue() {
        return hand.getValue();
    }

    // Gets hand object
    public Hand getHand() {
        return hand;
    }

    //reset by clearing all hands
    public void resetHand() {
        hand.clear();
    }


    public abstract void play(Deck deck);
}
