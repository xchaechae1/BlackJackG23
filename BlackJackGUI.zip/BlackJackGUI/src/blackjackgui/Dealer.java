package blackjackgui;
public class Dealer extends Participant {

    // Dealer draws cards until card value 17 or above
    @Override
    public void play(Deck deck) {
        System.out.println("\nDealer's turn...");
        System.out.println("Dealer's hand: " + getHand());

        // Keep drawing until greater or equal to 17
        while (getHandValue() <= 17) {
            Card card = deck.drawCard(); // Draw a card from the deck
            addCard(card);               // Add card to dealer's hand
            System.out.println("Dealer draws: " + card + " (Total: " + getHandValue() + ")");
        }

        // Dealer stands with 17 or above
        System.out.println("Dealer stands with: " + getHand());
    }
}
