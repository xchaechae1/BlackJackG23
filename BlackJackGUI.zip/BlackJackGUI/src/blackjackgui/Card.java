package blackjackgui;


public class Card {
    private String suit; // The suit of the card
    private String rank; // The rank of the card
    private int value;   // The value of the card in Blackjack

   
    public Card(String suit, String rank, int value) {
        this.suit = suit;
        this.rank = rank;
        this.value = value;
    }

    // Get the value of cards
    public int getValue() {
        return value;
    }

    // Get the suit of card
    public String getSuit() {
        return suit;
    }

    // Get the rank of card
    public String getRank() {
        return rank;
    }

    // Return a string to show what card recieved
    @Override
    public String toString() {
        return rank + " of " + suit;
    }
}
