package LRJ23;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MoneyManager {

    // Save player into file
    public static void save(Player player) {
        File file = new File(player.getUsername() + "_save.txt");
        try {
            if (player.getBalance() <= 0) {
                if (file.exists()) file.delete(); // delete the file if lose all money
            } else {
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write("Username: " + player.getUsername() + "\n");
                    writer.write("Balance: " + player.getBalance() + "\n");
                    writer.write("Games Played: " + player.getGamesPlayed() + "\n");
                    writer.write("Wins: " + player.getWins() + "\n");
                    writer.write("Losses: " + player.getLosses() + "\n");
                    writer.write("Draws: " + player.getDraws() + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error saving game: " + e.getMessage());
        }
    }

    // Load player from save file
    public static Player load(String username) {
        File file = new File(username + "_save.txt");
        if (file.exists()) {
            try (Scanner sc = new Scanner(file)) {
                String name = username;
                int balance = 100;
                int gamesPlayed = 0, wins = 0, losses = 0, draws = 0;

                while (sc.hasNextLine()) {
                    String line = sc.nextLine().trim();
                    if (line.startsWith("Username:")) name = line.split(":")[1].trim();
                    else if (line.startsWith("Balance:")) balance = Integer.parseInt(line.split(":")[1].trim());
                    else if (line.startsWith("Games Played:")) gamesPlayed = Integer.parseInt(line.split(":")[1].trim());
                    else if (line.startsWith("Wins:")) wins = Integer.parseInt(line.split(":")[1].trim());
                    else if (line.startsWith("Losses:")) losses = Integer.parseInt(line.split(":")[1].trim());
                    else if (line.startsWith("Draws:")) draws = Integer.parseInt(line.split(":")[1].trim());
                }

                Player player = new Player(name, balance);
                player.setGamesPlayed(gamesPlayed);
                player.setWins(wins);
                player.setLosses(losses);
                player.setDraws(draws);
                return player;

            } catch (Exception e) {
                System.out.println("Error loading save file: " + e.getMessage());
            }
        }
        return new Player(username, 100); // default player if new player start with $100
    }
}
