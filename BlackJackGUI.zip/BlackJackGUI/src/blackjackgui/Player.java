package blackjackgui;

import java.util.Scanner;

public class Player extends Participant {
    private String username;
    private int balance;
    private int gamesPlayed;
    private int wins;
    private int losses;
    private int draws;

    
    public Player(String username, int startingBalance) {
        super();
        this.username = username;
        this.balance = startingBalance;
        this.gamesPlayed = 0;
        this.wins = 0;
        this.losses = 0;
        this.draws = 0;
    }

    // Getters
    public String getUsername() { return username; }
    public int getBalance() { return balance; }
    public int getGamesPlayed() { return gamesPlayed; }
    public int getWins() { return wins; }
    public int getLosses() { return losses; }
    public int getDraws() { return draws; }

    // Setters to load from file
    public void setGamesPlayed(int games) { this.gamesPlayed = games; }
    public void setWins(int wins) { this.wins = wins; }
    public void setLosses(int losses) { this.losses = losses; }
    public void setDraws(int draws) { this.draws = draws; }

    // Update records and balance
    public void adjustBalance(int amount) { balance += amount; }
    public void recordWin() { wins++; gamesPlayed++; }
    public void recordLoss() { losses++; gamesPlayed++; }
    public void recordDraw() { draws++; gamesPlayed++; }

    @Override
    public void play(Deck deck) {
        Scanner sc = new Scanner(System.in);
        boolean playing = true;

        while (playing) {
            System.out.print("Hit or Stand? (H/S) or Q to quit: ");
            String choice = sc.nextLine().trim().toUpperCase();

            if (choice.equals("H")) {
                // Player hits
                Card card = deck.drawCard();
                addCard(card);
                System.out.println("You drew: " + card + " (Total: " + getHandValue() + ")");
                if (getHandValue() > 21) {
                    System.out.println("Bust!");
                    playing = false;
                }
            } else if (choice.equals("S")) {
                // Player stands
                playing = false;
            } else if (choice.equals("Q")) {
                // Player quits 
                System.out.println("Exiting game...");
                System.exit(0);
            } else {
                // Invalid input
                System.out.println("Invalid input! Please enter only H, S, or Q.");
            }
        }
    }
}
