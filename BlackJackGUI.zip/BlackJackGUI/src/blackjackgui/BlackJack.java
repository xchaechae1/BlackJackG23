package LRJ23;

import java.util.Scanner;

public class BlackJack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("Enter your username: ");  // prompt username
        
        String username = sc.nextLine().trim();

        
        Player player = MoneyManager.load(username); //player data collector
        Dealer dealer = new Dealer();

        boolean playing = true;

        while (playing && player.getBalance() > 0) {
            Deck deck = new Deck();
            deck.shuffle();

            
            player.resetHand(); //reset
            dealer.resetHand();

            //start dealing to player
            player.addCard(deck.drawCard()); 
            player.addCard(deck.drawCard());
            dealer.addCard(deck.drawCard());
            dealer.addCard(deck.drawCard());

            // Betting
            int bet = 0;
            while (true) {
                System.out.print("\nYou have $" + player.getBalance() + ". Enter your bet or Q to quit: ");
                String input = sc.nextLine().trim().toUpperCase();

                if (input.equals("Q")) {
                    System.out.println("Exiting game...");
                    System.exit(0);
                }

                try {
                    bet = Integer.parseInt(input);
                    if (bet > 0 && bet <= player.getBalance()) break;
                    System.out.println("Invalid bet amount.");
                } catch (NumberFormatException e) {
                    System.out.println("Please enter a number.");
                }
            }

            // dealers first card
            System.out.println("Dealer shows: " + dealer.getHand().getCards().get(0));
            System.out.println("Player's hand: " + player.getHand());

            // Player turn (hit/stand)
            player.play(deck);

            //Dealer plays
            if (player.getHandValue() <= 21) {
                dealer.play(deck);
            }

            // Compare results to determine winner
            int playerTotal = player.getHandValue();
            int dealerTotal = dealer.getHandValue();

            System.out.println("\nFinal hands:");
            System.out.println("Player: " + player.getHand() + " (Total: " + playerTotal + ")");
            System.out.println("Dealer: " + dealer.getHand() + " (Total: " + dealerTotal + ")");

            // update stats
            if (playerTotal > 21) {
                System.out.println("You have gone bust! Lose $" + bet);
                player.adjustBalance(-bet);
                player.recordLoss();
            } else if (dealerTotal > 21 || playerTotal > dealerTotal) {
                System.out.println("You win! +" + bet);
                player.adjustBalance(bet);
                player.recordWin();
            } else if (playerTotal < dealerTotal) {
                System.out.println("Dealer wins! -" + bet);
                player.adjustBalance(-bet);
                player.recordLoss();
            } else {
                System.out.println("Push! Bet returned.");
                player.recordDraw();
            }

            // Save balance and stats
            MoneyManager.save(player);

            // Continue playing if player still has money or player decides to quit
            if (player.getBalance() > 0) {
                System.out.print("\nPlay another round? (Y/N) or Q to quit: ");
                String again = sc.nextLine().trim().toUpperCase();
                if (again.equals("Q") || !again.equals("Y")) playing = false;
            } else {
                System.out.println("You're out of money!");
                playing = false;
            }
        }

        System.out.println("\nYou leave the table with $" + player.getBalance());
        System.out.println("=== Thanks for playing! ===");
        sc.close();
    }
}
    