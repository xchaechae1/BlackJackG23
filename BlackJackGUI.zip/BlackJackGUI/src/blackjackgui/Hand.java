package LRJ23;

import java.util.ArrayList;
import java.util.List;


public class Hand {
    private List<Card> cards; // Cards currently in the hand

    // empty hand
    public Hand() {
        cards = new ArrayList<>();
    }

    // Add card to  hand
    public void addCard(Card card) {
        cards.add(card);
    }

    // Get total value of cards
    public int getValue() {
        int total = 0;
        int aceCount = 0;

        // Sum all card values
        for (Card card : cards) {
            total += card.getValue();
            if (card.getRank().equals("Ace")) {
                aceCount++; // Keep track of Aces
            }
        }

        // Adjust Aces from 11 to 1 if total exceeds 21
        while (total > 21 && aceCount > 0) {
            total -= 10; // Count Ace as 1 instead of 11
            aceCount--;
        }

        return total;
    }

    // Get the list of cards in hand
    public List<Card> getCards() {
        return cards;
    }

    // Clear all cards from hand
    public void clear() {
        cards.clear();
    }

    // String showing value of hand
    @Override
    public String toString() {
        return cards.toString() + " (Value: " + getValue() + ")";
    }
}
